FORGE ICLR 2027

Upload this ZIP as a new Overleaf project.
Main document: main.tex
Compiler: pdfLaTeX

All files are in this folder. The manuscript, tables, algorithms and figure
code are consolidated in main.tex. references.bib contains the cited entries.
Manuscript and bibliography comments have been removed. Official template
files remain unchanged, including their license notices. The historical
implementation record named in the paper is mathematical_review.json.

The verified paper has nine main pages and 40 pages including disclosures,
references and appendices.
